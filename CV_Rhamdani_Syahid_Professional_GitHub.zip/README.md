# CV Profesional — Rhamdani Syahid

## Upload ke repository GitHub Pages yang sudah ada
1. Download lalu ekstrak ZIP ini.
2. Buka repository: `https://github.com/syahiddhani3/Cv-ramdanisyahid`
3. Upload/ganti file `index.html` di root repository dengan file `index.html` dari ZIP ini.
4. Upload folder `assets` beserta `profile.jpg`. Jika folder `assets` sudah ada, pastikan `profile.jpg` ada di dalamnya.
5. Commit perubahan.
6. Buka **Settings → Pages** dan pastikan source adalah branch `main`, folder `/(root)`.
7. Tunggu beberapa menit, lalu buka `https://syahiddhani3.github.io/Cv-ramdanisyahid/`.

## Catatan
- File utama harus bernama persis `index.html`.
- Jangan upload hanya file ZIP; upload isi ZIP.
- Periksa kembali data pribadi, tanggal pendidikan, nama perusahaan, jabatan, dan uraian tugas sebelum website dipublikasikan.
- Tombol “Simpan sebagai PDF” membuka dialog cetak browser; pilih “Save as PDF” jika tersedia.
